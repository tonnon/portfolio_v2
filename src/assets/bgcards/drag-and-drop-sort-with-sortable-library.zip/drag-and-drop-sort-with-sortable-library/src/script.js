var dragActivateDelayMS = 500;
var animationSpeedMS = 500;
var dragOpacity = 0.5;

var myList = document.getElementById("myList");

var sortOptions = {
  animation: animationSpeedMS,
  ghostClass: "sortable-ghost"
}

Sortable.create(myList, sortOptions);